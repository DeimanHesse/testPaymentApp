import { useForm } from 'react-hook-form';
import { addCard } from '../API/CardsAPI';

import "./hookForm.scss"

const HookForm = () => {

    const { 
        register,
        formState: {
            errors,
            isValid
        },
        handleSubmit,
        reset,
    } = useForm({
        mode: "onChange"
    });

   const onSubmit = async (data) => {
        let obj = {
            CardNumber: data.CardNumber.replace(/\s/g, ""),
            ExpDate: data.ExpDate.replace(/\s/g, "/"),
            Cvv: data.Cvv,
            Amount: data.Amount
        }

        try {
            const  data  = await addCard(obj);
            alert(`ID: ${data._id} Amount: ${data.Amount}`)
            console.log(data)
            
        } catch (error) {
            console.log(error);
        }

        reset();
    }


  

    const normalizeCardNumber = (value) => {
        return value.replace(/\s/g, "").match(/^[0-9]+$/)?.join(" ").match(/.{1,4}/g)?.join(" ").substr(0, 19) || ""
    }

    const normalizeExpDate = (value) => {
        return value.replace(/\s/g, "").match(/^[0-9]+$/)?.join(" ").match(/.{1,2}/g)?.join(" ").substr(0, 5) || ""
    }

    const normalizeCvv = (value) => {
        return value.replace(/\s/g, "").match(/^[0-9]+$/)?.join(" ").substr(0, 3) || ""
    }

    const normalizeAmount = (value) => {
        return value.replace(/\s/g, "").match(/^[0-9]+$/)?.join(" ") || ""
    }


    return (
        <div className="form">
            <div className="form__title">Payment form</div>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="form-item">
                <label htmlFor="CardNumber" className="form-item__label">Card Number</label>
                    <input 
                        className='form-item__input' 
                        maxLength='19'
                        inputMode='numeric'
                        autoComplete='cc-number'
                        type="phone" 
                        placeholder='0000 0000 0000 0000' 
                        ref={register}  
                        {...register('CardNumber', {
                            required: {
                                value: true,
                                message:"Поле обязательно для заполнения"
                            },
                            minLength: {
                                value: 19,
                                message: "должно быть 16 символов"
                            },
                            maxLength: {
                                value: 19,
                                message: "должно быть 16 символов"
                            },
                            onChange: (e) => {
                                const {value} = e.target
                                e.target.value = normalizeCardNumber(value)
                                
                            }, 
                        })}/>
                    <div className="form-item__error">
                    {errors?.CardNumber && <p>{errors?.CardNumber?.message}</p>}   
                    </div>
                </div>
                <div className="form-item">
                <label htmlFor="ExpDate" className="form-item__label">Expiration Date</label>
                    <input 
                        className='form-item__input'
                        maxLength='5'
                        inputMode='numeric'
                        autoComplete='cc-number'
                        type="phone" 
                        placeholder='01 / 21' 
                        ref={register} 
                        {...register('ExpDate', {
                            required: {
                                value: true,
                                message:"Поле обязательно для заполнения"
                            },
                            minLength: {
                                value: 5,
                                message: "должно быть 4 символоа"
                            },
                            maxLength: {
                                value: 5,
                                message: "должно быть 4 символоа"
                            },
                            onChange: (e) => {
                                const {value} = e.target
                                e.target.value = normalizeExpDate(value)
                            } 
                        })}/>
                    <div className="form-item__error">
                        {errors?.ExpDate && <p>{errors?.ExpDate?.message}</p>}    
                    </div>
                </div>
                <div className="form-item">
                <label htmlFor="Cvv" className="form-item__label">CVV</label>
                    <input className='form-item__input' 
                        inputMode='numeric'
                        autoComplete='cc-number'
                        type="phone" 
                        placeholder='993' 
                            maxLength="3"
                            {...register('Cvv', {
                            required: {
                                value: true,
                                message:"Поле обязательно для заполнения"
                            },
                            minLength: {
                                value: 3,
                                message: "должно быть 3 символа"
                            },
                            maxLength: {
                                value: 3,
                                message: "должно быть 3 символа"
                            },
                            onChange: (e) => {
                                const {value} = e.target
                                e.target.value = normalizeCvv(value)
                                
                            }, 
                        })}/>
                    <div className="form-item__error">
                        {errors?.Cvv && <p>{errors?.Cvv?.message}</p>}    
                    </div>
                </div>
                <div className="form-item">
                <label htmlFor="Amount" className="form-item__label">Amount</label>
                    <input className='form-item__input' 
                        type="phone" 
                        inputMode='numeric'
                        autoComplete='cc-number'
                        placeholder='1000' {...register('Amount', {
                                required: {
                                    value: true,
                                    message:"Поле обязательно для заполнения"
                                },
                                onChange: (e) => {
                                    const {value} = e.target
                                    e.target.value = normalizeAmount(value)
                                    
                                }, 
                        })}/>
                    <div className="form-item__error">
                        {errors?.Amount && <p>{errors?.Amount?.message}</p>}    
                    </div>
                </div>
            <button disabled={!isValid} className='form__button' type="submit">Отправить</button>
            </form>
           
        </div>
    )
    
}

export default HookForm;