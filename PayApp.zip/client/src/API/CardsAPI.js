import axios from 'axios';

export const addCard = async (obj) => {
    const {data} = await axios.post(`http://88.212.253.186:35229/api/cards`, obj);
    return data;
}