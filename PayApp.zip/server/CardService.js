import Card from "./Card.js";


class CardService {
    async create(card) {
        const createCard = await Card.create(card);
        return createCard;
    }
}


export default new CardService();
