import mongoose from 'mongoose';

const Card = new mongoose.Schema({
    CardNumber: {type: String, required: true},
    ExpDate: {type: String, required: true},
    Cvv: {type: String, required: true},
    Amount: {type: String}
})

export default mongoose.model('Card', Card)
