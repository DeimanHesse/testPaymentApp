import Router from 'express'
import CardController from "./CardController.js";

const router = new Router()

router.post('/cards', CardController.create)


export default router;
